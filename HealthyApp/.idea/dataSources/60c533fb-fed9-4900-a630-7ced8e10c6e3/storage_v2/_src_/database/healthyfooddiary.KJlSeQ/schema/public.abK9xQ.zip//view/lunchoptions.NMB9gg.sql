create view lunchoptions(id_option, name, calories, fat, protein, carbs, type_meal) as
SELECT "public.MealOption".id_option,
       "public.MealOption".name,
       "public.MealOption".calories,
       "public.MealOption".fat,
       "public.MealOption".protein,
       "public.MealOption".carbs,
       "public.MealOption".type_meal
FROM "public.MealOption"
WHERE "public.MealOption".type_meal = 'Lunch'::mealtype;

alter table lunchoptions
    owner to postgres;

