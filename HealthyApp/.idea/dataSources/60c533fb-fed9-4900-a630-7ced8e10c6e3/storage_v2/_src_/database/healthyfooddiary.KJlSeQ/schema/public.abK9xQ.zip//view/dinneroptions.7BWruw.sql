create view dinneroptions(id_option, name, calories, fat, protein, carbs, type_meal) as
SELECT "public.MealOption".id_option,
       "public.MealOption".name,
       "public.MealOption".calories,
       "public.MealOption".fat,
       "public.MealOption".protein,
       "public.MealOption".carbs,
       "public.MealOption".type_meal
FROM "public.MealOption"
WHERE "public.MealOption".type_meal = 'Dinner'::mealtype;

alter table dinneroptions
    owner to postgres;

